1.安装Python运行环境
略

2.安装调用C# dll必须的clr环境
在python调用c#dll库时要先安装库clr，即安装pythonnet，参考文章：https://www.cnblogs.com/kevin-Y/p/10235125.html（为在python中使用dotnet程序安装clr）

3.使用Python运行PythonCallDemo中的脚本
其中BouncyCastle.Crypto.dll、Newtonsoft.Json.dll、TuyaCloudIfLib.dll是运行依赖库
Cloud.py脚本通过clr对Tuya授权相关接口和类型进行了封装，以便Python调用
test.py脚本提供了授权完整流程的Demo，以供参考

4.test.py文件说明
由于保密原则，test.py中为提供具体的测试数据，请将测试数据赋值后再执行test.py脚本
