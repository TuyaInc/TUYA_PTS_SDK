import Cloud
from TuyaCloudIfLib import *
instance = TuyaCloudIf()

def main():
    #打印dll的版本信息
    print("DLL version = " + instance.GetDllVersion())

    #测试数据
    user = "hzty-fmqk"
    pwd = "duy87643"
    tokenid = "9jcuSGQFJ2gqQ3dv"
    sn = "CBBC04TJL00001"
    mac = "68572da984ff"

    #用户登录
    login_rsp = Cloud.login(user,pwd)
    if not login_rsp.success:
        print("Failed to login," + login_rsp.errorMsg)
        return

    #获取Token信息
    info_rsp = Cloud.get_token_info(tokenid)
    if info_rsp.success:
        firmware_name = info_rsp.result.fingerprint #固件名称
        firmware_version = info_rsp.result.firmwareVersion #固件版本
        pid = info_rsp.result.productId #PID
        country_code = info_rsp.result.countryCode #国家码
        wifi_hotspot_name = info_rsp.result.wifiHotspotName #WiFi名称
        wifi_password = info_rsp.result.wifiPassword  #WiFi密码
    else:
        print("Failed to get token information," + info_rsp.errorMsg)
        return

    #授权
    auth_rsp = Cloud.token_auth(tokenid,sn,mac)
    if auth_rsp.success:
        accesskey = auth_rsp.result.accessKey #授权key
        uuid = auth_rsp.result.uuid #UUID
    else:
        print("Failed to auth," + auth_rsp.errorMsg)
        return

    #授权校验
    validate_rsp = Cloud.token_auth_validate(tokenid,sn,uuid,mac,accesskey,wifi_hotspot_name,wifi_password)
    if validate_rsp.success == False or validate_rsp.result.result == False:
        print("Failed to validate:error:" + validate_rsp.errorMsg)
        return

    #授权二次校验
    check_rsp = Cloud.token_auth_check(tokenid,sn,uuid,mac,accesskey,wifi_hotspot_name,wifi_password)
    if check_rsp.success == False or check_rsp.result.result == False:
        print("Failed to check:error:" + check_rsp.errorMsg)
        return

if __name__ == '__main__':
    main()
