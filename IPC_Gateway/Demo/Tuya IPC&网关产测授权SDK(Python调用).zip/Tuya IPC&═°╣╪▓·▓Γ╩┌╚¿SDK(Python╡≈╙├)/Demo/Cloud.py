import clr
clr.AddReference("TuyaCloudIfLib")
clr.AddReference("BouncyCastle.Crypto")
from TuyaCloudIfLib import *

def login(user,pwd):
    req = UserLoginReqParas()         
    req.username = user
    req.password = pwd
    rsp = TuyaCloudIf.UserLogin(req)
    print("login result: " + str(rsp.success))
    return rsp

def get_token_info(tokenId):
    req = GetTokenInfoReqParas()
    req.tokenId = tokenId
    rsp = TuyaCloudIf.GetTokenInfo(req)
    print("get token info result: " + str(rsp.success))
    return rsp

def token_auth(tokenId,sn,mac):
    req = TokenAuthReq()
    req.tokenId = tokenId
    req.sn = sn
    req.mac = mac
    req.sftVersion = "sdk_call_py_1.0"
    rsp = TuyaCloudIf.TokenAuth(req)
    print("auth result: " + str(rsp.success))
    return rsp

def token_auth_validate(tokenId,sn,uuid,mac,accessKey,wifi_hotspot_name,wifi_password):
    req = TokenAuthValidateReq()
    req.tokenId = tokenId
    req.sn = sn
    req.mac = mac
    req.accessKey = accessKey
    req.uuid = uuid
    req.wifiHotspotName = wifi_hotspot_name
    req.wifiPassword = wifi_password
    req.sftVersion = "sdk_call_py_1.0"
    rsp = TuyaCloudIf.TokenAuthValidate(req)
    print("auth validate result: " + str(rsp.success))
    return rsp

def token_auth_check(tokenId,sn,uuid,mac,accessKey,wifi_hotspot_name,wifi_password):
    req = TokenAuthCheckReq()
    req.tokenId = tokenId
    req.sn = sn
    req.mac = mac
    req.accessKey = accessKey
    req.uuid = uuid
    req.wifiHotspotName = wifi_hotspot_name
    req.wifiPassword = wifi_password
    req.sftVersion = "sdk_call_py_1.0"
    rsp = TuyaCloudIf.TokenAuthCheck(req)
    print("auth check result: " + str(rsp.success))
    return rsp