import Cloud
from TuyaCloudIfLib import *
instance=TuyaCloudIf()


#打印dll的版本信息
print("DLL version = "+instance.GetDllVersion())

#用户登录
Cloud.login(username,password);
  
