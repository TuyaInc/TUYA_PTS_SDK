import clr
clr.AddReference("TuyaCloudIfLib")
clr.AddReference("BouncyCastle.Crypto")
from TuyaCloudIfLib import *



def login(user,pwd):
    LoginReq = UserLoginReqParas();         
    LoginReq.username = user;
    LoginReq.password = pwd;
    LoginRsp =UserLoginRspParas()
    LoginRsp =TuyaCloudIf.UserLogin(LoginReq)
    print("login result: "+str(LoginRsp.success))
    return LoginRsp.success

