﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Tuya.Model;

namespace ProductionDataAdapter
{
    class Program
    {
        private static readonly Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        public static void Main(string[] args)
        {
            Connecte("127.0.0.1", 8991);

            Console.ReadKey();
        }

        private static void Connecte(string ip, int port)
        {
            //连接到的目标IP
            IPAddress ipAddress = IPAddress.Parse(ip);
            IPEndPoint point = new IPEndPoint(ipAddress, port);

            try
            {
                //连接到服务器
                client.Connect(point);
                ShowMsg("连接成功");
                ShowMsg("服务器" + client.RemoteEndPoint.ToString());
                ShowMsg("客户端:" + client.LocalEndPoint.ToString());
                //连接成功后，就可以接收服务器发送的信息了

                Thread th = new Thread(ReceiveMsg);
                th.IsBackground = true;
                th.Start();
            }
            catch (Exception ex)
            {
                ShowMsg(ex.Message);
            }
        }

        //接收服务器的消息
        private static void ReceiveMsg()
        {
            while (true)
            {
                try
                {
                    var buffer = new byte[1024 * 1024];
                    var receivedLength = client.Receive(buffer);
                    if (receivedLength == 0) return;

                    //判断帧头
                    if (buffer[0] != 0x55 || buffer[1] != 0xaa)
                    {
                        ShowMsg($"{client.RemoteEndPoint.ToString()}:error data");
                        continue;
                    }

                    //判断数据长度
                    var dataLength = CalculateLength(buffer.Skip(2).Take<byte>(2).ToArray());
                    if (dataLength + 5 > receivedLength)
                    {
                        ShowMsg($"{client.RemoteEndPoint.ToString()}:error data length");
                        continue;
                    }

                    //计算帧头字段、数据长度字段、数据字段累加和
                    var sumCheck = SumCheck(buffer, dataLength + 4);
                    if (sumCheck != buffer[dataLength + 4])
                    {
                        ShowMsg($"{client.RemoteEndPoint.ToString()}:sum check error");
                        continue;
                    }

                    //Json格式：测试记录
                    var jsonData = Encoding.UTF8.GetString(buffer, 4, dataLength);

                    //C#对象：测试记录
                    var testRecord = JsonConvert.DeserializeObject<TestRecord<TestItemLog>>(jsonData);

                    ShowMsg(client.RemoteEndPoint.ToString() + ":" + jsonData);
                }
                catch (Exception ex)
                {
                    ShowMsg(ex.Message);
                    break;
                }
            }
        }

        private static void ShowMsg(string msg)
        {
            Console.WriteLine($"{msg}\r\n");
        }

        /// <summary>
        /// 计算字节所表示的长度(大端模式)
        /// </summary>
        /// <param name="lengthBytes"></param>
        /// <returns></returns>
        private static int CalculateLength(byte[] lengthBytes)
        {
            if (lengthBytes == null || lengthBytes.Length > 4) throw new Exception("error");
            int ret = 0;
            for (int i = 0; i < lengthBytes.Length; i++)
            {
                ret |= lengthBytes[lengthBytes.Length - i - 1] << (8 * i);
            }
            return ret;
        }

        /// <summary>
        /// 累加校验和
        /// </summary>
        /// <param name="memorySpage">需要校验的数据</param>
        /// <returns>返回校验和结果</returns>
        public static byte SumCheck(byte[] memorySpage, int length)
        {
            int num = 0;
            for (int i = 0; i < length; i++)
            {
                num += memorySpage[i];
            }
            byte[] value = System.BitConverter.GetBytes(num);
            return value[0];
        }
    }
}
