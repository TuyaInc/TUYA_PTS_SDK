﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;

namespace Tuya.Model
{
    public enum ProductionTestResult
    {
        /// <summary>
        /// 失败
        /// </summary>
        Fail = 0,

        /// <summary>
        /// 成功
        /// </summary>
        Pass = 1,

        /// <summary>
        /// 尚未开始
        /// </summary>
        NotStart = 2,

        /// <summary>
        /// 正在进行
        /// </summary>
        InHand = 4
    }


    /// <summary>
    /// 测试项日志
    /// </summary>
    public class TestItemLog
    {
        public int Index { get; set; }

        public TestItem TestItem { get; set; }

        public DateTime StartTime { get; set; }

        public DateTime EndTime { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public ProductionTestResult Result { get; set; }
       
        public string Data { get; set; }

        public string InfoCode { get; set; }
    }
}
