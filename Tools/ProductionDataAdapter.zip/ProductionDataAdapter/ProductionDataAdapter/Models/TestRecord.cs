﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;

namespace Tuya.Model
{
    /// <summary>
    /// 测试日志
    /// </summary>
    public class TestRecord<T>
    {
        public DateTime StartTime { get; set; }

        public DateTime EndTime { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public ProductionTestResult Result { get; set; }

        public IDictionary<string, string> Info { get; set; }

        public IList<T> ItemLogs { get; set; }

        public TestRecord()
        {
            Info = new Dictionary<string, string>();
            ItemLogs = new List<T>();
        }
    }
}
