﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Tuya.Model;
using Tuya.Module;
using Tuya.Module.ProtocolServer.WiFiCom;
using TuyaCloudIfLib;

namespace AuthorizeTest
{
    public partial class AuthorizeForm : Form
    {
        public AuthorizeForm()
        {
            InitializeComponent();
            //获取串口列表
            this.comboBoxCom.DropDown += (sender, e) =>
            {
                string[] portNames = SerialPort.GetPortNames();
                ComboBox comboBox = (ComboBox)sender;
                comboBox.Items.Clear();
                comboBox.Items.AddRange(portNames);
                comboBox.Items.Add("");
            };
        }

        private void AuthorizeForm_Load(object sender, EventArgs e)
        {
            
        }

        private void buttonAuth_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(this.textBoxToken.Text) ||
                String.IsNullOrWhiteSpace(this.textBoxSN.Text))
            {
                MessageBox.Show("Token或SN不能为空！");
                return;
            }
            bool result = false;

            //根据授权码获取授权码相关信息
            GetTokenInfoReqParas getTokenInfoReqParas = new GetTokenInfoReqParas() { tokenId = textBoxToken.Text };
            GetTokenInfoRspParas getTokenInfoRspParas = TuyaCloudIf.GetTokenInfo(getTokenInfoReqParas);
            if (!getTokenInfoRspParas.success)
            {
                MessageBox.Show(getTokenInfoRspParas.errorMsg);
                return;
            }

            var comPortPara = new ComPortParas()
            {
                PortName = this.comboBoxCom.SelectedItem as string,     //串口
                BaudRate = Convert.ToInt32(this.textBoxBaudRate.Text)   //波特率
            };
            var server = new CommunicationServerBuilder().UseSerialPort(comPortPara).Build<WiFiComServer>();
            byte aboutType = 0x00;
            byte needWriteMAC = 0x00;
            string readMac = "";
            string readMuid = "";
            if (server.Start()) //启动
            {
                //1. 进入测试模式
                var enterResult = server.SwitchTestMode(out var enterTestModeRsp, 400, 50);
                if (!enterResult)
                {
                    MessageBox.Show("进入测试模式失败！");
                    return;
                }
                aboutType = enterTestModeRsp.aboutType;//byte[1]
                needWriteMAC = enterTestModeRsp.needWriteMAC;//byte[0]

                //2. 读取固件MAC
                result = server.ReadMac(out ReadMACRsp macrsp_read, 1, 10, 200) && macrsp_read.Ret;
                if (!result)
                {
                    MessageBox.Show("获取MAC失败！");
                    return;
                }
                readMac = macrsp_read.MAC;
                readMuid = macrsp_read.MUID;
            }
            else
            {
                MessageBox.Show("串口打开失败");
                return;
            }
            //3.云端授权
            ProdTokenAuthReq authReq = new ProdTokenAuthReq
            {
                sn = this.textBoxSN.Text,               //SN
                tokenId = this.textBoxToken.Text,       //Token
                mac = readMac,                          //固件MAC
                muid = readMuid,                        //读取的MUID
                chipId = "",                            //芯片ID，填空
                sftVersion = Program.softwareVersion    //软件版本号
            };
            var authRsp = TuyaCloudIf.ProdTokenAuth(authReq);
            if (!authRsp.success)
            {
                MessageBox.Show($"授权失败：{authRsp.errorMsg}");
                return;
            }
            var accessKey = authRsp.result.accessKey;   //accessKey
            var uuid = authRsp.result.uuid;             //uuid
            var authMac = authRsp.result.mac;           //授权mac地址

            //4. 判断固件MAC与授权MAC是否相同
            if(readMac != authRsp.result.mac)
            {
                WriteMACReq writeMACReq = new WriteMACReq() { MAC = authRsp.result.mac };
                result = server.WriteMAC(writeMACReq, out BaseRsp writeRsp, 1, 10, 200) && writeRsp.Ret;
                if (!result)
                {
                    MessageBox.Show($"写入MAC：{authRsp.result.mac} 失败");
                    return;
                }
            }

            //5. 写入配置信息
            ConfigInfoReqAndRsp configInfoReqAndRsp = new ConfigInfoReqAndRsp()
            {
                Appwd = getTokenInfoRspParas.result.wifiPassword,
                ApSsid = getTokenInfoRspParas.result.wifiHotspotName,
                Auzkey = authRsp.result.accessKey,
                Uuid = authRsp.result.uuid,
                ProdTest = getTokenInfoRspParas.result.test
            };
            result = server.SetConfigInfo(configInfoReqAndRsp, out BaseRsp setConfigRsp, 1, 100, 50) && setConfigRsp.Ret;
            if (!result)
            {
                MessageBox.Show("写固件配置信息失败");
                return;
            }

            //6. 判断国家码是否为空
            if (!string.IsNullOrEmpty(getTokenInfoRspParas.result.countryCode))
            {
                SetCountryCodeReq setCountryCodeReq = new SetCountryCodeReq() { Country = getTokenInfoRspParas.result.countryCode };
                result = server.SetCountryCode(setCountryCodeReq, out BaseRsp countryRsp, 1, 100, 50) && countryRsp.Ret;
                if (!result)
                {
                    MessageBox.Show("写入国家码失败");
                    return;
                }
            }

            //5.授权信息校验
            var validateReq = new ProdTokenAuthValidateReq()
            {
                tokenId = this.textBoxToken.Text,       //Token
                sn = this.textBoxSN.Text,               //SN
                uuid = uuid,                            //uuid
                muid = readMuid,                        //muid
                mac = authMac,                          //mac
                accessKey = accessKey,                  //accessKey
                wifiHotspotName = getTokenInfoRspParas.result.wifiHotspotName,
                wifiPassword = getTokenInfoRspParas.result.wifiPassword,
                chipId = "",
                sftVersion = Program.softwareVersion    //软件版本号
            };
            var validateRsp = TuyaCloudIf.ProdTokenAuthValidate(validateReq);
            if (!validateRsp.success)
            {
                MessageBox.Show($"授权校验失败：{validateRsp.errorMsg}");
            }
            else
            {
                MessageBox.Show("授权成功");
            }
        }
    }
}
