﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TuyaCloudIfLib;

namespace AuthorizeTest
{
    public partial class LoginForm : Form
    {
        private bool isSuccess;
        /// <summary>
        /// 登录结果
        /// </summary>
        public bool IsLoginSuccess
        {
            get
            {
                return isSuccess;
            }
        }
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(this.textBoxUsername.Text) ||
                String.IsNullOrWhiteSpace(this.textBoxPassword.Text))
            {
                MessageBox.Show("所输入账号密码不能为空！");
                return;
            }

            var req = new UserLoginReqParas
            {
                username = this.textBoxUsername.Text,   //登录账号
                password = this.textBoxPassword.Text    //登录密码
            };

            //2.登录账号
            var rsp = TuyaCloudIf.UserLogin(req);

            if (rsp.success)
            {
                this.isSuccess = true;
                this.Close();
            }
            else
            {
                MessageBox.Show($"账号登录失败：{rsp.errorMsg}");
            }
        }
    }
}
