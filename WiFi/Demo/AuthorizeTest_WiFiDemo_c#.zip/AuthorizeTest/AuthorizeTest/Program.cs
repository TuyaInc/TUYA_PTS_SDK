﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using TuyaCloudIfLib;

namespace AuthorizeTest
{
    static class Program
    {
        public static string softwareIdentity = "WiFiSDKDemo";   //软件标识
        public static string softwareVersion = "1.0.0";               //软件版本
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //1.设置云端工作环境
            TuyaCloudIf.SetUrlSftVer(softwareVersion, softwareIdentity, TuyaCloudIf._LoginUrlType.Release);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            using (LoginForm loginForm = new LoginForm())
            {
                loginForm.ShowDialog();
                if (!loginForm.IsLoginSuccess)
                {
                    return;
                }
            }

            Application.Run(new AuthorizeForm());


        }
    }
}
