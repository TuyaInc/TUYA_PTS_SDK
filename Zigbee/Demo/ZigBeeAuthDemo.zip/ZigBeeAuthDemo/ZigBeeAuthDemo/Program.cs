﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TuyaCloudIfLib;

namespace ZigBeeAuthDemo
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var authResult = Auth(out var msg);
            var strAuthResult = authResult ? "成功" : "失败";
            System.Console.WriteLine($"授权{strAuthResult}：{msg}");
        }

        private static bool Auth(out string msg)
        {
            var result = true;
            msg = "";

            //模拟信息
            var sn = "O123456";
            var tokenId = "testtokenid";
            var mac = "aaaaaaaaa";

            //获取Token信息
            var tokenInfoReq = new GetTokenInfoReqParas()
            {
                tokenId = tokenId
            };
            var tokenInfoRsp = TuyaCloudIf.GetTokenInfo(tokenInfoReq);
            if (!tokenInfoRsp.success)
            {
                msg += "获取Token信息失败";
                return false;
            }


            //云端授权
            var authReq = new AuthReqParas()
            {
                tokenId = tokenId,
                mac = mac,
                id = mac,
                sn = sn,
                type = tokenInfoRsp.result.type ?? "",
                sftVersion = TuyaCloudIf.SftVersion
            };
            var authRsp = TuyaCloudIf.Authorize(authReq);
            if (authRsp.success == false)
            {
                msg += $"云端授权失败:{authRsp.errorMsg}";
                return false;
            }

            //云端授权验证
            var validateReq = new AuthValidateReqParasV2()
            {
                id = mac ?? "",
                mac = mac ?? "",
                sn = sn ?? "",
                tokenId = tokenId ?? "",
                sftVersion = TuyaCloudIf.SftVersion ?? "",
                type = tokenInfoRsp.result.type ?? "",
                mode = "",
                baselineVersion = "",
                fingerprint = tokenInfoRsp.result.fingerprint ?? "",
                firmwareVersion = tokenInfoRsp.result.firmwareVersion ?? "",
                test = tokenInfoRsp.result.test,
                productKey = tokenInfoRsp.result.productKey ?? "",
                wifiPassword = "",
                wifiHotspotName = "",
                accessKey = authRsp.result.accessKey ?? "",
                operationType = "validate",
                hid = ""
            };
            var validateRsp = TuyaCloudIf.AuthorizeValidate(validateReq);
            if (validateRsp.success == false)
            {
                msg += $"云端授权验证失败:{validateRsp.errorMsg}";
                return false;
            }

            //添加授权日志
            AddAuthLogReqParas req = new AddAuthLogReqParas();
            req.log.tokenId = tokenId;
            req.log.uuid = authRsp.result.id;
            req.log.hid = mac ?? "";
            req.log.sn = sn ?? "";
            req.log.activeTime = GetUTC();
            req.log.firmwareInfo = tokenInfoRsp.result.fingerprint + tokenInfoRsp.result.firmwareVersion;
            req.log.authStatus = (result == true ? 1 : 0);
            var logRsp = TuyaCloudIf.AddAuthLog(req);
            if (logRsp.success == false)
            {
                msg += $"云端添加授权日志失败:{logRsp.errorMsg}";
                return false;
            }

            return true;
        }

        public static string GetUTC()
        {
            TimeZone tz = TimeZone.CurrentTimeZone;
            DateTime vDate = DateTime.Now.ToUniversalTime();
            DateTime dtZone = new DateTime(1970, 1, 1, 0, 0, 0);

            return ((int)(vDate.Subtract(dtZone).TotalSeconds)).ToString();
        }
    }
}
