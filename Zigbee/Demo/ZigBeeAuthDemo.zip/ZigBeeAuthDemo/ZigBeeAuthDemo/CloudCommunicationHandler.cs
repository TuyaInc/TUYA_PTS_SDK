﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TuyaCloudIfLib;

namespace TuyaCloudIfLib
{
    public static class CloudCommunicationHandler
    {
        /// <summary>
        /// 无工单授权接口
        /// </summary>
        /// <param name="req"></param>
        /// <param name="rsp"></param>
        /// <returns></returns>
        public static bool TokenAuth(TokenAuthReq req, out TokenAuthRsp rsp)
        {
            rsp = TuyaCloudIf.CallRemoteInterface<TokenAuthReq, TokenAuthRsp>(req, "s.pt.dev.production.token.auth", "1.0");
            if (!rsp.success)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 无工单授权校验
        /// </summary>
        /// <param name="req"></param>
        /// <param name="rsp"></param>
        /// <returns></returns>
        public static bool TokenAuthValidate(TokenAuthValidateReq req, out TokenAuthValidateRsp rsp)
        {
            rsp = TuyaCloudIf.CallRemoteInterface<TokenAuthValidateReq, TokenAuthValidateRsp>(req, "s.pt.dev.production.token.auth.validate", "1.0");
            if (!rsp.success)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 无工单授权二次检测接口
        /// </summary>
        /// <param name="req"></param>
        /// <param name="rsp"></param>
        /// <returns></returns>
        public static bool TokenAuthCheck(TokenAuthCheckReq req, out TokenAuthCheckRsp rsp)
        {
            rsp = TuyaCloudIf.CallRemoteInterface<TokenAuthCheckReq, TokenAuthCheckRsp>(req, "s.pt.dev.production.token.auth.check", "1.0");
            if (!rsp.success)
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// 获取无工单授权成功数量
        /// </summary>
        /// <param name="req"></param>
        /// <param name="rsp"></param>
        /// <returns></returns>
        public static bool TokenAuthGetSuccessAmount(TokenAuthGetSuccessAmountReq req, out TokenAuthGetSuccessAmountRsp rsp)
        {
            rsp = TuyaCloudIf.CallRemoteInterface<TokenAuthGetSuccessAmountReq, TokenAuthGetSuccessAmountRsp>(req, "s.pt.dev.production.token.auth.get.success.amount", "1.0");
            if (!rsp.success)
            {
                return false;
            }
            return true;
        }
    }

    #region 无工单授权接口
    public class TokenAuthReq : BaseRequest
    {
        public string sn;//可选
        public string tokenId;//不可为空
        public string sftVersion;
        public string muid;// wifi乐鑫模块才上传芯片ID
        public string mac;// 工具从模块读取mac，然后上传云端
        public string chipId;//安全芯片ID，安全模组的项目才会传
    }

    public class TokenAuthRsp : BaseResponse
    {
        public AuthRspResult result;
        public class AuthRspResult
        {
            public string uuid;//模块uuid（模块的uuid这里由云端生成，生成规则沿用老逻辑，根据不同的联网模式来生成uuid）
            public string mac;//mac地址
            public string accessKey;//accessKey
            public string pskKey;//psk通讯秘钥
        }
    }
    #endregion

    #region 无工单授权校验接口
    public class TokenAuthValidateReq : BaseRequest
    {
        public string sn;//可选
        public string tokenId;//不可为空
        public string sftVersion;
        public string uuid;// 不可为空，模块uuid，从模块里读取出来
        public string mac;// 不可为空，mac地址，从模块里读取出来
        public string accessKey;// 不可为空，授权码，从模块里读取出来
        public string muid;// muid
        public string wifiHotspotName;// 热点名称，从模块里读取出来
        public string wifiPassword;// wifi密码，从模块里读取出来
        public string chipId;//安全芯片ID，安全模组的项目才会传
    }

    public class TokenAuthValidateRsp : BaseResponse
    {
        public TokenAuthValidateRspResult result;
        public class TokenAuthValidateRspResult
        {
            public bool result;// 授权检测结果
            public string failureDepict;// 授权检测失败原因描述
        }
    }
    #endregion

    #region 无工单授权二次校验接口
    public class TokenAuthCheckReq : BaseRequest
    {
        public string sn;//可选
        public string tokenId;//不可为空
        public string sftVersion;
        public string uuid;// 不可为空，模块uuid，从模块里读取出来
        public string mac;// 不可为空，mac地址，从模块里读取出来
        public string accessKey;// 不可为空，授权码，从模块里读取出来
        public string muid;// muid
        public string wifiHotspotName;// 热点名称，从模块里读取出来
        public string wifiPassword;// wifi密码，从模块里读取出来
        public string chipId;//安全芯片ID，安全模组的项目才会传
    }

    public class TokenAuthCheckRsp : BaseResponse
    {
        public TokenAuthCheckRspResult result;
        public class TokenAuthCheckRspResult
        {
            public bool result;// 授权检测结果
            public string failureDepict;// 授权检测失败原因描述
        }
    }
    #endregion

    #region 无工单授权成功数量
    public class TokenAuthGetSuccessAmountReq : BaseRequest
    {
        public string tokenId;//不可为空
    }
    public class TokenAuthGetSuccessAmountRsp : BaseResponse
    {
        public int result;// 授权成功数量
    }
    #endregion

}
